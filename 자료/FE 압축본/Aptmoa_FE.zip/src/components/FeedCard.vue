<template>
  <v-col cols="12" :md="size === 2 ? 6 : size === 3 ? 4 : undefined">
    <base-card
      :height="value.prominent ? 450 : 350"
      color="grey lighten-1"
      dark
    >
      <v-img
        :src="require(`@/assets/articles/${value.hero}`)"
        height="100%"
        gradient="rgba(0, 0, 0, .42), rgba(0, 0, 0, .42)"
      >
        <v-row v-if="!value.prominent" class="fill-height text-right ma-0">
          <v-col cols="12">
            <v-chip
              label
              class="mx-0 mb-2 text-uppercase"
              color="grey darken-3"
              text-color="white"
              small
              @click.stop=""
            >
              {{ value.category }}
            </v-chip>

            <h3 class="title font-weight-bold mb-2">
              {{ value.title }}
            </h3>

            <div class="caption">
              {{ value.author }}<br />Date : {{ value.date }}
            </div>
          </v-col>

          <v-col align-self="end">
            <v-chip
              class="text-uppercase ma-0"
              color="primary"
              label
              small
              @click="goDetail"
            >
              Read More
            </v-chip>
          </v-col>
        </v-row>
      </v-img>
    </base-card>
  </v-col>
</template>

<script>
export default {
  name: "FeedCard",

  props: {
    size: {
      type: Number,
      required: true
    },
    value: {
      type: Object,
      default: () => ({})
    }
  },
  methods: {
    goDetail() {
      if (this.value.category === "News") {
        this.$router.push({
          name: "newsDetail",
          params: { newsno: this.value.newsno }
        });
      } else if (this.value.category === "Notice") {
        this.$router.push({
          name: "noticeDetail",
          params: { noticeno: this.value.noticesno }
        });
      } else {
        console.log("Q&A");
        this.$router.push({
          name: "qnaDetail",
          params: { qnano: this.value.qnano }
        });
      }
    }
  }
};
</script>

<style>
.v-image__image {
  transition: 0.3s linear;
}
</style>
