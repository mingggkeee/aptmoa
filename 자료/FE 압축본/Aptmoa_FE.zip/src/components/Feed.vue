<template>
  <v-container>
    <v-row>
      <v-col cols="12">
        <slot />
      </v-col>

      <feed-card
        v-for="(article, i) in articles"
        :key="article.title"
        :size="layout[i]"
        :value="article"
      />
    </v-row>
  </v-container>
</template>

<script>
// Utilities
import { mapState } from "vuex";

export default {
  name: "Feed",

  components: {
    FeedCard: () => import("@/components/FeedCard")
  },

  data: () => ({
    layout: [2, 2, 2, 2, 3, 3, 3, 3, 3, 3]
  }),

  computed: {
    ...mapState(["articles"])
  },

  watch: {
    page() {
      window.scrollTo(0, 0);
    }
  }
};
</script>
