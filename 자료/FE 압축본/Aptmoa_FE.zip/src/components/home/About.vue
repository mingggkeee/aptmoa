<template>
  <v-container id="about" tag="section">
    <base-subheading>About Us</base-subheading>
    <p>
      이용 중 문제가 생기시면 아래의 연락처로 문의주시기 바랍니다.
    </p>
  </v-container>
</template>

<script>
export default {
  name: "HomeAbout"
};
</script>
