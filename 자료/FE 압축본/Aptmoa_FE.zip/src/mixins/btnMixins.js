export default {
  methods: {
    isMobile() {
      return this.$vuetify.breakpoint.mobile;
    }
  }
};
