package com.pjt.aptmoa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AptmoaApplication {

	public static void main(String[] args) {
		SpringApplication.run(AptmoaApplication.class, args);
	}

}
