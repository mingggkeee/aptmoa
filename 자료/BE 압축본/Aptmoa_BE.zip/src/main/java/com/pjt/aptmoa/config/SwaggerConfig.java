package com.pjt.aptmoa.config;

import static springfox.documentation.builders.PathSelectors.regex;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

//http://localhost:9999/aptmoa/swagger-ui/index.html

@Configuration
@EnableSwagger2
public class SwaggerConfig {

	@Bean
	public Docket postsApi() {
		return new Docket(DocumentationType.SWAGGER_2).apiInfo(apiInfo()).groupName("aptmoaVueJS").select()
				.apis(RequestHandlerSelectors.basePackage("com.pjt.aptmoa.controller")).paths(regex("/aptmoa/.*")).build();
	}

	private ApiInfo apiInfo() {
		return new ApiInfoBuilder().title("Aptmoa VueJS REST API").description(
				"<h2>Aptmoa API Reference for Developers</h2>Swagger를 이용한 VUEJS API<br><img src=\"./ssafy.png\">\"")
				.contact(new Contact("Aptmoa", "https://github.com/mingggkeee/aptmoa", "mksu234@naver.com")).license("Aptmoa License")
				.licenseUrl("https://github.com/mingggkeee/aptmoa").version("1.0").build();
	}

}
